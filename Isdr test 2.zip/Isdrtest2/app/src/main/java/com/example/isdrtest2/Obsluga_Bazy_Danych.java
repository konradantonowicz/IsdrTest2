package com.example.isdrtest2;


        import android.annotation.SuppressLint;
        import android.content.Context;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;
        import android.database.sqlite.SQLiteOpenHelper;
        import android.util.Log;
        import java.io.File;
        import java.io.FileOutputStream;
        import java.io.InputStream;
        import java.io.OutputStream;
        import java.util.ArrayList;
        import java.util.List;

public class Obsluga_Bazy_Danych extends SQLiteOpenHelper
    {
        private static final String DBNAME = "BazaDanychPytan.db";
        @SuppressLint("SdCardPath") private static final String DBLOCATION = "/data/data/" + BuildConfig.APPLICATION_ID + "/databases/";
        private Context mContext;
        private SQLiteDatabase mDatabase;
        public Obsluga_Bazy_Danych(Context context)
            {
                super(context, DBNAME, null, 1);
                this.mContext = context;
            }
        @Override public void onCreate(SQLiteDatabase db)
            {
            }
        @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
            {
            }
        public void openDatabase()
            {
                String dbPath = mContext.getDatabasePath(DBNAME).getPath();
                if (mDatabase != null && mDatabase.isOpen()) {
                    return;
                }
                mDatabase = SQLiteDatabase.openDatabase(dbPath, null, SQLiteDatabase.OPEN_READWRITE);
            }
        public void closeDatabase()
            {
                if (mDatabase != null) {
                    mDatabase.close();
                }
            }
        public boolean sprawdz()
            {
                boolean czyjest = true;
                File database = mContext.getDatabasePath(Obsluga_Bazy_Danych.DBNAME);
                if (!database.exists()) {
                    getReadableDatabase();
                    close();
                    copyDatabase(mContext);
                    czyjest = false;
                }
                return czyjest;
            }
        private void copyDatabase(Context context)
            {
                try {
                    InputStream inputStream = context.getAssets().open(Obsluga_Bazy_Danych.DBNAME);
                    String outFileName = Obsluga_Bazy_Danych.DBLOCATION + Obsluga_Bazy_Danych.DBNAME;
                    OutputStream outputStream = new FileOutputStream(outFileName);
                    byte[] buff = new byte[1024];
                    int length;
                    while ((length = inputStream.read(buff)) > 0) {
                        outputStream.write(buff, 0, length);
                    }
                    outputStream.flush();
                    outputStream.close();
                    Log.w("AktywnoscGlowna", "DB copied");
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        public List<DaoPytZazPytPraw> PokazWersetyBibli()
            {
                openDatabase();


                Cursor k = mDatabase.rawQuery("select OdpowiedzPrawidlowa,Odpowiedz_zaznaczona from Pytania",null);



                List<DaoPytZazPytPraw> ListaOdpPrawZaz = new ArrayList<>();

                DaoPytZazPytPraw pytaniaDao = null;
                k.moveToFirst();
                while (!k.isAfterLast()) {
                    String Tresc_odpPrawidlowa = k.getString(0);
                    String Tresc_odpZaznaczona = k.getString(1);

                    pytaniaDao = new DaoPytZazPytPraw(Tresc_odpPrawidlowa,Tresc_odpZaznaczona);
                    ListaOdpPrawZaz.add(pytaniaDao);
                    k.moveToNext();
                }
                k.close();
                closeDatabase();
                return ListaOdpPrawZaz;
            }
    }
