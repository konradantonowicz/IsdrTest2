package com.example.isdrtest2;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;
public class MainActivity extends AppCompatActivity
    {
        @Override protected void onCreate(Bundle savedInstanceState)
            {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);



                Obsluga_Bazy_Danych obsluga_bazy_danych = new Obsluga_Bazy_Danych(this);
                obsluga_bazy_danych.sprawdz();

                List<DaoPytZazPytPraw>lista = new ArrayList<>(obsluga_bazy_danych.PokazWersetyBibli());
                for (DaoPytZazPytPraw a : lista) {
                    System.out.println(a.getOdpowiedzPrawidlowa());
                }



            }


            }

